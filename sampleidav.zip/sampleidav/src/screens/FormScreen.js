import React from 'react';
import Tabla from "../components/Tabla";
import Form from "../components/Form"
import Navbar from "../components/Navbar";

export default function FormScreen() {
    return (

        <div>
            <Navbar/>
            <div style={{
                display: "flex",
                flexDirection: "column",
                alignContent: "center",
                justifyContent: "center",
                padding: 50
            }}>
                <Tabla/>
            </div>

            <div style={{
                display: "flex",
                flexDirection: "row",
                alignContent: "center",
                justifyContent: "space-between",
                padding: 50,
                paddingLeft : 200,
                paddingRight : 200
            }}>
                <Form/>
                <Form/>
            </div>
        </div>

    );
}
