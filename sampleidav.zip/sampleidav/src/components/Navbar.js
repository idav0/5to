import React from "react";
import { styled } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

const StyledAppBar = styled(AppBar)({
    flexGrow: 1,
});

const Navbar = () => {
    return (
        <StyledAppBar position="static">
            <Toolbar>
                <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                    Mi aplicación
                </Typography>
                <Button color="inherit">Inicio</Button>
                <Button color="inherit">Acerca de</Button>
                <Button color="inherit" href={"/Contacto"}>Contacto</Button>
            </Toolbar>
        </StyledAppBar>
    );
};

export default Navbar;
