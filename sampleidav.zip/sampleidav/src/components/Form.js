import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";

const StyledForm = styled("form")({
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    "& > *": {
        margin: "8px",
        width: "25ch",
    },
});

export default function Form() {
    const [formValues, setFormValues] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        city: "",
        country: "",
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormValues((prevState) => ({ ...prevState, [name]: value }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(formValues);
        // Aquí puedes enviar el formulario al servidor o hacer cualquier otra cosa con los datos
    };

    return (
        <StyledForm onSubmit={handleSubmit}>
            <TextField
                id="name"
                name="name"
                label="Nombre"
                variant="outlined"
                value={formValues.name}
                onChange={handleChange}
            />
            <TextField
                id="email"
                name="email"
                label="Email"
                variant="outlined"
                value={formValues.email}
                onChange={handleChange}
            />
            <TextField
                id="phone"
                name="phone"
                label="Teléfono"
                variant="outlined"
                value={formValues.phone}
                onChange={handleChange}
            />
            <TextField
                id="address"
                name="address"
                label="Dirección"
                variant="outlined"
                value={formValues.address}
                onChange={handleChange}
            />
            <TextField
                id="city"
                name="city"
                label="Ciudad"
                variant="outlined"
                value={formValues.city}
                onChange={handleChange}
            />
            <FormControl variant="outlined" sx={{ width: "25ch" }}>
                <InputLabel id="country-label">País</InputLabel>
                <Select
                    labelId="country-label"
                    id="country"
                    name="country"
                    value={formValues.country}
                    onChange={handleChange}
                    label="País"
                >
                    <MenuItem value="">
                        <em>None</em>
                    </MenuItem>
                    <MenuItem value="USA">USA</MenuItem>
                    <MenuItem value="México">México</MenuItem>
                    <MenuItem value="Argentina">Argentina</MenuItem>
                </Select>
            </FormControl>
            <Button variant="contained" sx={{ mt: 2 }} type="submit">
                Enviar
            </Button>
        </StyledForm>
    );
}
